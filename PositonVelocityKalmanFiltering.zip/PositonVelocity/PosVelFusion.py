# -*- coding: utf-8 -*-
"""
Created on Sun Sep 27 11:06:06 2020

@author: duxiaoqin
@Functions:
    (1)Toy Example for Kalman Filtering;
"""

import numpy as np
import matplotlib.pyplot as plt

def main():
    np.random.seed()
    steps = 2000
    dt = 1/20
    force_min, force_max = 1000, 2000
    mass = 1000
    forces = []
    for step in range(steps):
        if step % 100 == 0:
            force = np.random.randint(force_min, force_max)
            forces.append(force)
        else:
            forces.append(forces[-1])
    Ut = np.array(forces) / mass
    F = np.array([[1, dt], [0, 1]])
    B = np.array([[dt**2/2], [dt]])
    H = np.eye(2)
    Qmu = np.array([0.0, 0.0])
    Q = np.array([[0.5, 0.0], [0.0, 1.0]])
    Rmu = np.array([0.0, 0.0])
    R = np.array([[5.0, 0.0], [0.0, 10.0]])
    P = np.array([[0.0, 0.0], [0.0, 0.0]])
    I = np.eye(2)
    
    Xt_hat = np.array([[0], [0]])
    Xt = Xt_hat + np.random.multivariate_normal(Qmu, Q).reshape((-1, 1))
    Yt = np.dot(H, Xt) + np.random.multivariate_normal(Rmu, R).reshape((-1, 1))
    Xts, Xts_hat, Yts = Xt.copy(), Xt_hat.copy(), Yt.copy()
    for step in range(1, steps):
        Xt = np.dot(F, Xt) + np.dot(B, Ut[step]) + np.random.multivariate_normal(Qmu, Q).reshape((-1, 1))
        Yt = np.dot(H, Xt) + np.random.multivariate_normal(Rmu, R).reshape((-1, 1))

        #Kalman Filtering
        #State Prediction
        Xt_hat = np.dot(F, Xt_hat) + np.dot(B, Ut[step])
        P = np.dot(np.dot(F, P), F.T) + Q
        #Measurement Update
        K = np.dot(np.dot(P, H.T), np.linalg.inv(np.dot(np.dot(H, P), H.T) + R))
        Xt_hat = Xt_hat + np.dot(K, Yt - np.dot(H, Xt_hat))
        P = np.dot(I - np.dot(K, H), P)

        Xts, Xts_hat, Yts = np.c_[Xts, Xt], np.c_[Xts_hat, Xt_hat], np.c_[Yts, Yt]
    
    plt.plot(Xts[0, :], Xts[1, :], color = 'blue', alpha = 1.0, label = 'Real State')
    plt.plot(Yts[0, :], Yts[1, :], color = 'orange', alpha = 1.0, label = 'Measured State')
    plt.plot(Xts_hat[0, :], Xts_hat[1, :], color = 'lime', alpha = 1.0, label = 'Estimated State')
    plt.legend()
    plt.get_current_fig_manager().window.showMaximized()
    plt.show()

if __name__ == '__main__':
    main()